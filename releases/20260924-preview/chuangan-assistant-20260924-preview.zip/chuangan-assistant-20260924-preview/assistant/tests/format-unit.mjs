import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const code=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8').split('function render(){')[0];
const context=vm.createContext({});vm.runInContext(code,context);
const html=vm.runInContext(`formatted('<script>alert(1)</script> [1] [2]\\n\\n| 项目 | 值 |\\n|---|---|\\n| 电流 | 9 A |\\n\\n1. 停机\\n2. 设置',[{id:1,url:'https://www.cschueun.com/product_detail/48.html',title:'官方资料'},{id:2,url:'javascript:alert(1)',title:'禁止'}])`,context);
assert.ok(!html.includes('<script>'));assert.ok(html.includes('&lt;script&gt;'));assert.ok(!html.includes('javascript:'));assert.ok(!html.includes('inline-citation'));assert.ok(!html.includes('[1]'));assert.ok(!html.includes('[2]'));assert.ok(html.includes('<table>'));assert.ok(html.includes('<ol start="1">'));assert.ok(html.includes('<li>停机</li>'));
console.log('PASS hidden citations, untrusted HTML escaping, parameter table and numbered steps.');

for(const text of ['产品如下[3]：','产品如下[3](https://www.cschueun.com/product/3.html)：',String.raw`产品如下[\[3\]](https://www.cschueun.com/product/3.html)：`,'产品如下<sup>3</sup>：','产品如下[^3]：','产品如下【3】：']){
 context.sample=text;assert.equal(vm.runInContext('displayAnswer(sample)',context),'产品如下：');
}
context.sample='1. 设置 P0-26 为 2，9/13 A，范围 [0, 100]，单位 m²，`arr[3]`';
assert.equal(vm.runInContext('displayAnswer(sample)',context),'1. 设置 P0-26 为 2，9/13 A，范围 [0, 100]，单位 m²，`arr[3]`');
console.log('PASS reference markers hidden in display/copy, numbers and code preserved.');
