const $=id=>document.getElementById(id),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let sessions=[],active=null,busy=false,uploading=false,thinking=false,controller=null;
const current=()=>sessions.find(s=>s.id===active);
const toast=text=>{$('toast').textContent=text;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),4000)};
function ensure(){if(!current()){active=crypto.randomUUID?crypto.randomUUID():String(Date.now());sessions.unshift({id:active,title:'新对话',messages:[],files:[]})}return current()}
function controls(){for(const id of ['thinking','upload','new-chat'])$(id).disabled=busy||uploading;$('send').disabled=busy||uploading||!$('prompt').value.trim();$('stop').hidden=!busy;$('thinking').setAttribute('aria-pressed',String(thinking))}
// Hide reference markers only in display/copy; keep raw answers for server evidence checks.
function displayAnswer(text){return String(text).split(/(```[\s\S]*?```|`[^`\n]*`)/g).map((part,i)=>i%2?part:part
 .replace(/\[(?:\\?\[)?\^?\d+(?:\s*[,，、-]\s*\d+)*(?:\\?\])?\]\([^\n)]*\)/g,'')
 .replace(/<sup>\s*(?:\[)?\d+(?:\s*[,，、-]\s*\d+)*(?:\])?\s*<\/sup>/gi,'')
 .replace(/\\?\[\^?\d+\\?\]|【\d+】/g,'')
 ).join('')}
// Escape all model text before minimal formatting. No model HTML is executed.
function formatted(text,sources=[]){return displayAnswer(text).split(/(```[\s\S]*?```)/g).map(part=>{
 if(part.startsWith('```'))return '<pre class="code-block"><code>'+esc(part.replace(/^```[^\n]*\n?/,'').replace(/```$/,''))+'</code></pre>';
 const lines=esc(part).replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>').replace(/`([^`\n]+)`/g,'<code>$1</code>').split('\n'),out=[];
 const cells=line=>line.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(x=>x.trim());
 for(let i=0;i<lines.length;i++){
  if(lines[i].includes('|')&&lines[i+1]&&/^\s*\|?\s*:?-{3,}/.test(lines[i+1])){
   out.push('<div class="table-scroll"><table><thead><tr>'+cells(lines[i]).map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>');i+=2;
   for(;i<lines.length&&lines[i].includes('|');i++)out.push('<tr>'+cells(lines[i]).map(x=>'<td>'+x+'</td>').join('')+'</tr>');out.push('</tbody></table></div>');i--;continue;
  }
  if(/^\s*\d+[.、]\s+/.test(lines[i])){
   const start=Number(lines[i].match(/\d+/)[0]);out.push('<ol start="'+start+'">');
   for(;i<lines.length&&/^\s*\d+[.、]\s+/.test(lines[i]);i++)out.push('<li>'+lines[i].replace(/^\s*\d+[.、]\s+/,'')+'</li>');out.push('</ol>');i--;continue;
  }
  if(/^\s*[-*]\s+/.test(lines[i])){
   out.push('<ul>');for(;i<lines.length&&/^\s*[-*]\s+/.test(lines[i]);i++)out.push('<li>'+lines[i].replace(/^\s*[-*]\s+/,'')+'</li>');out.push('</ul>');i--;continue;
  }
  out.push(lines[i].replace(/^#{1,6}\s+(.+)$/,'<h3>$1</h3>').replace(/^<strong>(操作步骤|注意事项|使用步骤)[：:]?<\/strong>$/,'<h3>$1</h3>'));
 }
 return '<div class="answer-text">'+out.join('\n')+'</div>';
 }).join('')}
function render(){const s=current();$('welcome').hidden=!!s?.messages.length;$('messages').innerHTML=(s?.messages||[]).map((m,i)=>m.role==='user'?`<article class="message user"><div class="user-bubble">${esc(m.content)}${m.fileNames?.length?'<div class="attached-names">附件：'+m.fileNames.map(esc).join('、')+'</div>':''}</div></article>`:`<article class="message assistant"><div class="assistant-heading"><span class="mini-mark">睿</span>睿控 AI <span class="demo-badge">${m.thinking?'深度思考':'产品问答'}</span></div><div class="answer">${m.status?'<div class="generation-status">'+esc(m.status)+'</div>':''}${formatted(m.content||'',m.sources||[])}${m.error?'<div class="answer-error">'+esc(m.error)+'</div>':''}${m.followups?.length?'<section class="followups" aria-label="延伸提问"><div class="followups-label">你可能还想问</div>'+m.followups.map(q=>'<button class="followup-question" data-prompt="'+esc(q)+'" '+(busy||uploading?'disabled':'')+'><span>'+esc(q)+'</span><span class="followup-arrow" aria-hidden="true">↗</span></button>').join('')+'</section>':''}<div class="message-actions"><button data-copy="${i}">复制</button></div></div></article>`).join('');$('history').innerHTML=sessions.map(s=>'<button data-session="'+s.id+'" class="'+(s.id===active?'active':'')+'">'+esc(s.title)+'</button>').join('')||'<div class="history-empty">从一个问题开始</div>';$('attachments').innerHTML=(s?.files||[]).map(f=>'<span class="attachment-chip">'+esc(f.name)+' <button data-remove="'+f.id+'" aria-label="移除 '+esc(f.name)+'" '+(busy?'disabled':'')+'>×</button></span>').join('');$('conversation').scrollTop=$('conversation').scrollHeight;controls()}
async function api(url,opts){const r=await fetch(url,opts);const b=await r.json();if(!r.ok)throw new Error(b.error||'请求失败');return b}
async function send(text){const question=(text??$('prompt').value).trim();if(!question||busy||uploading)return;const s=ensure();if(!s.messages.length)s.title=question.slice(0,35);const history=s.messages.filter(m=>m.complete||m.role==='user').map(m=>({role:m.role,content:m.content}));
 if(history.length>40)return toast('对话较长，请开启新对话');
 const priorFiles=s.files.map(f=>f.id);s.messages.push({role:'user',content:question,fileNames:s.files.map(f=>f.name)});const reply={role:'assistant',content:'',sources:[],status:'正在连接…',thinking};s.messages.push(reply);busy=true;controller=new AbortController();$('prompt').value='';render();
 try{
  const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question,history,files:priorFiles,thinking}),signal:controller.signal});
  if(!r.ok){let b;try{b=await r.json()}catch{}throw new Error(b?.error||'服务请求失败')}
  const reader=r.body.getReader(),decoder=new TextDecoder();let buffer='',done=false;
  const event=block=>{const name=block.match(/^event: (.+)$/m)?.[1],raw=block.match(/^data: (.+)$/m)?.[1];if(!raw)return;const data=JSON.parse(raw);if(name==='status')reply.status=data.text;if(name==='delta'){reply.status='';reply.content+=data.text}if(name==='sources')reply.sources=data.sources;if(name==='error')throw new Error(data.error);if(name==='done'){done=true;reply.complete=!data.truncated;reply.status='';if(data.sources)reply.sources=data.sources;reply.followups=Array.isArray(data.followups)?data.followups:[];if(data.truncated)reply.error='本次回答达到长度限制，可继续追问。'}render()};
  for(;;){const part=await reader.read();if(part.done)break;buffer+=decoder.decode(part.value,{stream:true});let i;while((i=buffer.indexOf('\n\n'))>=0){event(buffer.slice(0,i));buffer=buffer.slice(i+2)}}if(!done)throw new Error('连接中断，回答未完成');
 }catch(e){reply.status='';reply.error=e.name==='AbortError'?'已停止生成':e.message}
 finally{busy=false;controller=null;render()}
}
$('send').onclick=()=>send();$('stop').onclick=()=>controller?.abort();$('prompt').oninput=controls;$('prompt').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send()}};
$('thinking').onclick=()=>{thinking=!thinking;controls()};$('new-chat').onclick=()=>{if(busy||uploading)return;active=null;$('prompt').value='';render()};$('menu').onclick=()=>$('sidebar').classList.toggle('open');$('info').onclick=()=>$('modal').showModal();$('close-modal').onclick=()=>$('modal').close();$('upload').onclick=()=>$('file-input').click();
$('file-input').onchange=async()=>{if(busy||uploading)return;const s=ensure(),selected=[...$('file-input').files];if(s.files.length+selected.length>5){$('file-input').value='';return toast('每个对话最多五个附件')}uploading=true;controls();try{for(const file of selected){if(file.size>10*1024*1024)throw new Error(file.name+' 超过 10 MB');toast('正在读取 '+file.name);const form=new FormData();form.append('file',file);const result=await api('/api/files',{method:'POST',body:form});s.files.push(result);render()}toast('文件已读取，可以提问')}catch(e){toast(e.message)}finally{uploading=false;$('file-input').value='';render()}};
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.prompt){send(b.dataset.prompt)}if(b.dataset.session&&!busy&&!uploading){active=b.dataset.session;$('sidebar').classList.remove('open');render()}if(b.dataset.remove&&!busy&&!uploading){try{await api('/api/files?id='+encodeURIComponent(b.dataset.remove),{method:'DELETE'});current().files=current().files.filter(f=>f.id!==b.dataset.remove);render()}catch(e){toast(e.message)}}if(b.dataset.copy){try{await navigator.clipboard.writeText(displayAnswer(current().messages[Number(b.dataset.copy)].content));toast('已复制')}catch{toast('请选中文字复制')}}});
api('/api/health').then(h=>{if(h.knowledge)$('knowledge-status').textContent=`知识来源：${h.knowledge.officialPages} 个官网页面、${h.knowledge.pdfFiles||0} 份PDF（${h.knowledge.pdfPages||0} 页）、${h.knowledge.productImages||0} 张产品资料图片，以及客户问答 ${h.knowledge.customerQuestions} 条。采集时间：${h.knowledge.builtAt.slice(0,10)}。资料不足时主动查找官网；客户问答 ${h.knowledge.quarantined} 条已隔离。`}).catch(()=>toast('服务暂时无法连接'));render();
