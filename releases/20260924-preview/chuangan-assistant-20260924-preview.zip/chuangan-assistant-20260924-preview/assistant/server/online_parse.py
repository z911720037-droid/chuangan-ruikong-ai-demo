"""Parse a bounded official PDF already fetched by the Node host allowlist."""
import json,logging,sys,re
from pypdf import PdfReader
logging.getLogger('pypdf').setLevel(logging.CRITICAL)
try:
 import resource
 resource.setrlimit(resource.RLIMIT_AS,(768*1024*1024,768*1024*1024));resource.setrlimit(resource.RLIMIT_CPU,(45,45))
except (ImportError,ValueError):pass
reader=PdfReader(sys.argv[1]);pages=[]
if len(reader.pages)>600:raise ValueError('PDF exceeds online parse limit')
for i,p in enumerate(reader.pages):
 t=(p.extract_text(extraction_mode='layout')or'').encode('utf-8',errors='replace').decode('utf-8')
 t='\n'.join(re.sub(r'[ \t]{2,}',' | ',x.strip())for x in t.splitlines()if x.strip())
 if t:pages.append({'page':i+1,'text':t[:50000]})
print(json.dumps({'pages':pages,'totalPages':len(reader.pages)},ensure_ascii=False))
