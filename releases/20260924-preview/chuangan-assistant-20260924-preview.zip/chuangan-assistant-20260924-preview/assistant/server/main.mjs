import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
import {runChat,validateInput} from './chat.mjs';
import {manifest,sourceDocument} from './knowledge.mjs';
const exec=promisify(execFile),root=fileURLToPath(new URL('../',import.meta.url));
const env=process.env,port=Number(env.PORT||18083),host=env.HOST||'127.0.0.1',origin=new URL(env.PUBLIC_ORIGIN||`http://127.0.0.1:${port}`);
const maxConcurrent=Number(env.MAX_CONCURRENT_REQUESTS||4),globalMinute=Number(env.GLOBAL_REQUESTS_PER_MINUTE||60),ipMinute=Number(env.PER_IP_REQUESTS_PER_MINUTE||30),dailyLimit=Number(env.DAILY_REQUEST_LIMIT||500);
if(!env.DEEPSEEK_API_KEY)throw new Error('DEEPSEEK_API_KEY required');
for(const n of [port,maxConcurrent,globalMinute,ipMinute,dailyLimit])if(!Number.isInteger(n)||n<1)throw new Error('Invalid server limits');
const state=env.RAG_STATE_DIR||path.join(os.tmpdir(),'chuangan-general-state');await fs.mkdir(state,{recursive:true,mode:0o700});
const quotaFile=path.join(state,'quota.json');let quota={day:'',count:0};try{quota=JSON.parse(await fs.readFile(quotaFile,'utf8'))}catch(e){if(e.code!=='ENOENT')throw e}
let quotaWrites=Promise.resolve();
const assets=new Map();for(const [name,type] of [['index.html','text/html'],['app.js','text/javascript'],['styles.css','text/css']])assets.set('/'+name,{body:await fs.readFile(path.join(root,'web',name)),type:type+'; charset=utf-8'});
const visitors=new Map(),rate=new Map();let active=0,uploads=0,starts=[];
const clean=()=>{const now=Date.now();for(const [id,s] of visitors)if(now-s.at>3600000)visitors.delete(id);for(const [ip,s] of rate)if(now-s.at>60000)rate.delete(ip)};
const timer=setInterval(clean,60000);timer.unref();
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data))};
async function read(req,limit){let size=0,parts=[];for await(const p of req){size+=p.length;if(size>limit)throw new Error('请求或文件过大');parts.push(p)}return Buffer.concat(parts)}
function imageType(data){if(data.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';if(data[0]===255&&data[1]===216&&data[2]===255)return 'image/jpeg';if(/^GIF8[79]a/.test(data.subarray(0,6).toString()))return 'image/gif';if(data.subarray(0,4).toString()==='RIFF'&&data.subarray(8,12).toString()==='WEBP')return 'image/webp';return null}
function session(req,res){const match=req.headers.cookie?.match(/(?:^|;\s*)ca_session=([a-f0-9]{48})(?:;|$)/);let id=match?.[1];if(!id||!visitors.has(id)){clean();if(visitors.size>=1000)throw new Error('当前访客过多，请稍后重试');id=crypto.randomBytes(24).toString('hex');visitors.set(id,{at:Date.now(),files:new Map()});res.setHeader('Set-Cookie',`ca_session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600${origin.protocol==='https:'?'; Secure':''}`)}const s=visitors.get(id);s.at=Date.now();return s}
function admit(req){const now=Date.now(),ip=req.socket.remoteAddress;let r=rate.get(ip);if(!r||now-r.at>60000){r={at:now,count:0};rate.set(ip,r)}if(++r.count>ipMinute)return false;return true}
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'");
 try{
  if(![origin.host,`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host))return json(res,400,{error:'访问地址不正确'});
  const url=new URL(req.url,'http://'+req.headers.host);
  if(req.method==='GET'&&url.pathname==='/api/health')return json(res,200,{ready:true,mode:'company_products',knowledgeMode:'official_documents_and_professional',database:false,embedding:false,features:{chat:true,history:true,thinking:true,web:false,officialKnowledge:true,files:true,images:true},knowledge:{officialPages:manifest.pages,productPages:manifest.productPages,pdfFiles:manifest.pdfFiles,pdfPages:manifest.pdfPages,productImages:manifest.productImages,customerQuestions:manifest.faqCount,quarantined:Object.keys(manifest.quarantined).length,builtAt:manifest.builtAt},searchProvider:'官网页面、手册与图片索引，缺失时主动联网核查',fileTtlSeconds:3600});
  if(req.method==='GET'&&url.pathname.startsWith('/api/knowledge/source/')){const key=url.pathname.slice('/api/knowledge/source/'.length);const d=sourceDocument(key);if(!d||d.kind!=='customer_faq')return json(res,404,{error:'来源不存在'});return json(res,200,{title:d.title,status:d.status,reviewNote:d.reviewNote,text:d.status==='quarantined'?'该条原答案已隔离，不作为操作依据。':d.text})}
  if(req.method==='GET'&&!url.pathname.startsWith('/api/')){const asset=assets.get(url.pathname==='/'?'/index.html':url.pathname);if(!asset)return json(res,404,{error:'Not found'});res.setHeader('Content-Type',asset.type);res.end(asset.body);return}
  if(req.headers.origin&&req.headers.origin!=='http://'+req.headers.host&&req.headers.origin!==origin.origin)return json(res,403,{error:'请在本站页面操作'});
  if(!['/api/chat','/api/files'].includes(url.pathname))return json(res,404,{error:'Not found'});
  if(!admit(req))return json(res,429,{error:'请求较频繁，请稍后再试'});
  const s=session(req,res);
  if(url.pathname==='/api/files'){
   if(req.method==='DELETE'){s.files.delete(url.searchParams.get('id'));return json(res,200,{ok:true})}
   if(req.method!=='POST')return json(res,405,{error:'Method not allowed'});
   if(uploads>=2)return json(res,429,{error:'文件正在处理，请稍后重试'});
   if(!req.headers['content-type']?.startsWith('multipart/form-data'))return json(res,415,{error:'请选择文件上传'});
   if(s.files.size>=20)return json(res,400,{error:'本次访问已保留 20 个临时附件，请先移除旧附件'});
   uploads++;
   try{
    const raw=await read(req,11*1024*1024);
    const request=new Request('http://localhost/upload',{method:'POST',headers:{'Content-Type':req.headers['content-type']},body:raw});
    const form=await request.formData(),file=form.get('file');
    if(!file||typeof file.arrayBuffer!=='function'||file.size>10*1024*1024||!file.size)throw new Error('单个文件需为 1 字节至 10 MB');
    const name=path.basename(file.name).slice(0,160),data=Buffer.from(await file.arrayBuffer()),id=crypto.randomBytes(16).toString('hex'),mime=imageType(data);
    let saved;
    if(mime){if(data.length>5*1024*1024)throw new Error('图片最大 5 MB');saved={id,name,image:true,mime,data,size:data.length}}
    else{
     const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'ca-upload-'));
     try{
      const filename=path.join(tmp,'input');await fs.writeFile(filename,data,{mode:0o600});
      let stdout;
      try{({stdout}=await exec(env.ASSISTANT_PYTHON||'python3',[path.join(root,'server/files.py'),filename,name],{timeout:30000,maxBuffer:1000000}))}catch(e){try{throw new Error(JSON.parse(e.stdout).error)}catch(parsed){if(parsed instanceof SyntaxError)throw new Error('文件解析失败或耗时过长');throw parsed}}
      const result=JSON.parse(stdout);if(result.error)throw new Error(result.error);saved={id,name,text:result.text,size:data.length};
     }finally{await fs.rm(tmp,{recursive:true,force:true})}
    }
    const used=[...visitors.values()].flatMap(v=>[...v.files.values()]).reduce((n,f)=>n+(f.data?.length||Buffer.byteLength(f.text||'')),0);
    if(used+(saved.data?.length||Buffer.byteLength(saved.text||''))>128*1024*1024)throw new Error('附件缓存已满，请稍后上传');
    s.files.set(id,saved);return json(res,200,{id,name,size:saved.size,type:saved.image?'image':'text',characters:saved.text?.length||0,expiresInSeconds:3600});
   }finally{uploads--}
  }
  if(req.method!=='POST')return json(res,405,{error:'Method not allowed'});
  if(!req.headers['content-type']?.includes('application/json'))return json(res,415,{error:'请求格式错误'});
  const body=validateInput(JSON.parse((await read(req,900000)).toString('utf8')));
  const files=body.files.map(id=>{const f=s.files.get(id);if(!f)throw new Error('附件不存在或已过期，请重新上传');return f});
  starts=starts.filter(t=>Date.now()-t<60000);
  if(active>=maxConcurrent||starts.length>=globalMinute)return json(res,429,{error:'当前服务繁忙，请稍后重试'});
  const day=new Date().toISOString().slice(0,10);if(quota.day!==day)quota={day,count:0};if(quota.count>=dailyLimit)return json(res,429,{error:'今日问答额度已用完'});
  active++;starts.push(Date.now());quota.count++;
  const savedQuota=JSON.stringify(quota);quotaWrites=quotaWrites.then(()=>fs.writeFile(quotaFile,savedQuota,{mode:0o600}));
  const controller=new AbortController();res.on('close',()=>controller.abort());
  const emit=(event,data)=>{if(!res.destroyed)res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)};
  let heartbeat;
  try{
   await quotaWrites;
   res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','X-Accel-Buffering':'no'});res.flushHeaders();
   heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': heartbeat\n\n')},10000);
   const t=performance.now();const result=await runChat(body,files,env,emit,{signal:controller.signal});
   console.log(JSON.stringify({event:'chat_complete',ms:Math.round(performance.now()-t),web:!!body.web,thinking:!!body.thinking,files:files.length,tokens:(result.usage?.total_tokens||0)+(result.searchUsage?.total_tokens||0)+(result.auditUsage?.total_tokens||0)+(result.repairUsage?.total_tokens||0)+(result.onlineUsage?.total_tokens||0),truncated:result.truncated}));
  }catch(e){if(!controller.signal.aborted){emit('error',{error:e.message||'生成失败，请重试'});console.warn(JSON.stringify({event:'chat_failed',type:e.name}))}}
  finally{clearInterval(heartbeat);active--;res.end()}
 }catch(e){if(!res.headersSent)json(res,400,{error:e instanceof SyntaxError?'请求格式错误':e.message||'请求失败'});else res.end()}
});
server.requestTimeout=300000;server.headersTimeout=15000;server.listen(port,host,()=>console.log(JSON.stringify({event:'ready',mode:'company_products',host,port,database:false,embedding:false,maxConcurrent})));
