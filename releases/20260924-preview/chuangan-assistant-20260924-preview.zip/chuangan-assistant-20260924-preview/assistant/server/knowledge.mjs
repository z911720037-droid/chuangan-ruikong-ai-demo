import fs from 'node:fs';
import {normalizeModel} from './online.mjs';
import {extractTechnicalIntent,matchesProduct} from './intent.mjs';
const corpus=JSON.parse(fs.readFileSync(new URL('../knowledge/corpus.json',import.meta.url),'utf8'));
if(!corpus.documents?.length||!corpus.manifest?.pages)throw Error('Official knowledge corpus missing');
export const manifest=corpus.manifest;
export const catalog=corpus.documents.filter(d=>d.kind==='official'&&/product_detail/.test(d.url)).map(d=>d.title.split('-长沙')[0]).join('；');
export const faqCatalog=corpus.documents.filter(d=>d.kind==='customer_faq').map(d=>d.number+'. '+d.title.split(' · ').at(-1)).join('；');
export function sourceDocument(key){return corpus.documents.find(d=>d.key===key)}
function terms(text){const s=text.toLowerCase().replace(/\s+/g,'');const a=s.match(/[a-z]+[a-z\d-]*|\d+(?:\.\d+)?|[\u4e00-\u9fff]+/g)||[];return [...new Set(a.flatMap(t=>/^[\u4e00-\u9fff]+$/.test(t)?Array.from({length:Math.max(1,t.length-1)},(_,i)=>t.slice(i,i+2)):[t]))].filter(t=>!['什么','怎么','如何','一下','请问','创安','公司','睿控','电气','这个','产品'].includes(t))}
const chunks=corpus.documents.flatMap(d=>{
 if(d.kind==='customer_faq'){
  // Keep originals for provenance/search, but withhold unreviewed numerical prescriptions from generation.
  const general=d.text.split(/[。；;\n]/).filter(sentence=>!/[0-9０-９]|参数号|接线|接触器|自动复位|保护阈值|端子|法规|消防/.test(sentence)).join('。');
  return [{...d,matchText:d.text,text:d.status==='quarantined'?'该问答已隔离，不能引用原答案。待复核原因：'+d.reviewNote:(general||'该问答的具体参数或操作细节尚待技术复核，本轮不提供。')+'\n原文中的未核验数字与操作细节已省略，不得自行补全。'}];
 }
 // Paragraph boundaries, with bounded complete-paragraph windows (not fixed 500-character cutting).
 const lines=d.text.split('\n'),out=[];let buf=[];
 for(const line of lines){if(buf.join('\n').length+line.length>2600&&buf.length){out.push({...d,text:buf.join('\n')});buf=[]}buf.push(line)}
 if(buf.length)out.push({...d,text:buf.join('\n')});return out;
});
const indexed=chunks.map(d=>({...d,normalized:normalizeModel(d.text),tokens:new Set(terms(d.title+' '+(d.matchText||d.text)))}));
const df=new Map();for(const d of indexed)for(const t of d.tokens)df.set(t,(df.get(t)||0)+1);
export function retrieve(query,limit=7){
 const ts=terms(query);if(!ts.length)return [];
 const requested=[...query.matchAll(/第?\s*(\d{1,3})\s*问/g)].map(x=>'faq-'+x[1]);
 const fullModels=[...query.toUpperCase().matchAll(/(?:CA|CAG|CE|CP|CF|CL|CBR|CM|CB|TZ)\d+[A-Z0-9]*(?:-[A-Z0-9./()-]+)+/g)].map(m=>normalizeModel(m[0]));
 const families=[...query.toUpperCase().matchAll(/(?:CA|CAG|CE|CP|CF|CL|CBR|CM|CB|TZ)\d+/g)].map(m=>m[0]);
 const codes=[...query.toUpperCase().matchAll(/\b(?:P[A-F0-9]|F[A-F0-9]|PN)[-]?\d{2,4}\b/g)].map(m=>normalizeModel(m[0]));
 const intent=extractTechnicalIntent(query);
 const ranked=indexed.filter(d=>matchesProduct(d,intent)).map(d=>{let score=requested.includes(d.key)?1000:0;for(const t of ts)if(d.tokens.has(t))score+=(Math.log(1+indexed.length/(df.get(t)||1)))*(d.title.toLowerCase().includes(t)?2.5:1);if(fullModels.some(m=>d.normalized.includes(m)))score+=300; if(families.some(m=>d.title.toUpperCase().includes(m)))score+=15; if(codes.some(m=>d.normalized.includes(m))){score+=70;if(/功能参数表|功能码.*名称/.test(d.text))score+=25;if(d.text.split('\n').some(line=>codes.some(c=>normalizeModel(line.split('|')[0]).startsWith(c))))score+=100;}if(d.extraction==='verified_table'&&fullModels.some(m=>d.normalized.includes(m)))score+=200;return {d,score}}).filter(x=>x.score>2).sort((a,b)=>b.score-a.score);
 const focusedFaq=ranked[0]?.d.kind==='customer_faq'&&ranked[0].score>(ranked[1]?.score||0)*1.3;
 const selected=[],seen=new Set();for(const {d,score} of ranked){if(focusedFaq&&selected.length)break;if(seen.has(d.key))continue;seen.add(d.key);selected.push({...d,score});if(selected.length>=limit)break}
 // Reserve an official result when FAQ wins on application wording.
 if(!focusedFaq&&!selected.some(d=>d.kind==='official')){const official=ranked.find(x=>x.d.kind==='official');if(official){if(selected.length===limit)selected.pop();selected.push(official.d)}}
 return selected.map(({tokens,matchText,normalized,...d},i)=>({...d,id:i+1}));
}
export function publicSource(d){return {id:d.id,key:d.key,title:d.title,url:d.url,kind:d.kind,status:d.status,reviewNote:d.reviewNote,retrievedAt:d.retrievedAt,page:d.page,extraction:d.extraction}}
