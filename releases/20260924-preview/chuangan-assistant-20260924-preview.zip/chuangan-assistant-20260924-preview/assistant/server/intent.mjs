// These are literal text extractions, not verified manufacturer specifications.
export function extractTechnicalIntent(question){
 const normalized=question.normalize('NFKC').toUpperCase().replace(/[‐‑–—]/g,'-');
 const models=[...new Set(normalized.match(/\b(?:CA|CAG|CE|CP|CF|CL|CBR|CM)\d+[A-Z0-9]*(?:-[A-Z0-9./-]+)?/g)||[])];
 const series=[...new Set(models.map(m=>m.match(/^[A-Z]+\d+/)?.[0]).filter(Boolean))];
 const powers=[...normalized.matchAll(/(\d+(?:\.\d+)?)\s*(KW|千瓦|GB|PB)\b/g)].map(m=>({value:Number(m[1]),label:m[2]}));
 const voltages=[...normalized.matchAll(/(\d+(?:\.\d+)?)\s*(KV|V|伏)/g)].map(m=>({value:Number(m[1]),unit:m[2]}));
 const codes=[...new Set(normalized.match(/\b(?:P[A-F0-9]|F[A-F0-9]|PN)[-]?\d{2,4}\b/g)||[])];
 const topics=[['额定电流',/额定.*电流|输出电流|输入电流/],['估算',/估算|估计|计算|公式/],['型号含义',/型号|含义|代表|什么意思/],['选型',/选型|选择|选多大/],['故障排查',/故障|跳闸|过流|过压|欠压/]].filter(([,r])=>r.test(question)).map(([name])=>name);
 return {models,series,powers,voltages,topics,codes,provenance:'用户文字提取；未核实的型号命名解释必须标注通常/推断，非厂家规格'};
}
export function matchesProduct(d,intent){
 if(intent.series.length!==1||d.kind==='customer_faq')return true;
 const target=intent.series[0];
 const productParents=(d.parents||[]).filter(p=>/product_detail/.test(p.parent)).map(p=>p.parentTitle).join(' ');
 const text=(d.title+' '+productParents).toUpperCase().replace(/(^|[^A-Z0-9])600U(?![A-Z0-9])/g,' CA600ULTRA ').replace(/(^|[^A-Z0-9])500U(?![A-Z0-9])/g,' CA500ULTRA ');
 const names=[...text.matchAll(/(?:CA|CAG|CE|CP|CF|CL|CBR|CM|CB|TZ)\d+[A-Z0-9]*/g)].map(m=>m[0]);
 const requested=intent.models.map(m=>m.split('-')[0]);
 if(!names.length&&d.extraction)return false;
 return !names.length||names.some(n=>requested.includes(n));
}
export function selectEvidence(documents,intent){
 let selected=documents.filter(d=>matchesProduct(d,intent));
 if(intent.models.length&&selected.some(d=>d.kind==='official'&&['pdf_text','verified_table','pdf_table'].includes(d.extraction)))selected=selected.filter(d=>d.kind!=='customer_faq'||d.status==='quarantined');
 return selected.map((d,i)=>({...d,id:i+1}));
}
