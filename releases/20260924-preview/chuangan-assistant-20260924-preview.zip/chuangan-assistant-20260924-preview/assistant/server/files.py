"""Extract uploaded documents without a database; never execute document content."""
import sys, json, pathlib, zipfile, xml.etree.ElementTree as ET

LIMIT = 100000
MAX_EXPANDED = 40 * 1024 * 1024
def extract(filename, name):
    ext = pathlib.Path(name).suffix.lower()
    if ext == '.pdf':
        from pypdf import PdfReader
        doc = PdfReader(filename)
        if doc.is_encrypted and not doc.decrypt(''):
            raise ValueError('PDF 已加密，请先解除密码')
        if len(doc.pages) > 200:
            raise ValueError('单份 PDF 最多 200 页，请拆分上传')
        parts, n, has_text = [], 0, False
        for i, page in enumerate(doc.pages):
            content = page.extract_text() or ''
            has_text = has_text or bool(content.strip())
            t = f'\n[PDF 第 {i+1} 页]\n' + content
            n += len(t)
            if n > LIMIT:
                raise ValueError('文件文本超过 10 万字符，请拆分后上传；未截断分析')
            parts.append(t)
        text = ''.join(parts)
        if not has_text:
            raise ValueError('PDF 没有可提取文字；请上传页面图片或带文本层的 PDF')
        return text
    if ext in ('.docx', '.xlsx'):
        with zipfile.ZipFile(filename) as z:
            if len(z.infolist()) > 3000 or sum(x.file_size for x in z.infolist()) > MAX_EXPANDED:
                raise ValueError('压缩文档展开后过大，请拆分')
            ns = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main', 's':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            if ext == '.docx':
                root = ET.fromstring(z.read('word/document.xml'))
                parts = [''.join(p.itertext()) for p in root.findall('.//w:p', ns)]
            else:
                shared = []
                if 'xl/sharedStrings.xml' in z.namelist():
                    shared = [''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si', ns)]
                parts = []
                for sheet in sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')):
                    parts.append('\n[' + sheet + ']')
                    for row in ET.fromstring(z.read(sheet)).findall('.//s:row', ns):
                        cells = []
                        for c in row.findall('s:c', ns):
                            value = c.find('s:v', ns)
                            val = value.text or '' if value is not None else ''
                            if c.get('t') == 's': val = shared[int(val)]
                            if c.get('t') == 'inlineStr': val = ''.join(c.find('s:is', ns).itertext())
                            f = c.find('s:f', ns)
                            if f is not None: val = f'[公式={f.text}; 缓存值={val}; 未重新计算]'
                            cells.append(c.get('r','') + '=' + val)
                        parts.append('\t'.join(cells))
            text = '\n'.join(parts)
    elif ext in ('.txt','.md','.csv','.json','.py','.js','.ts','.log','.yaml','.yml'):
        raw = pathlib.Path(filename).read_bytes()
        try: text = raw.decode('utf-8-sig')
        except UnicodeDecodeError: text = raw.decode('gb18030')
        if '\x00' in text: raise ValueError('不支持二进制文件')
    else:
        raise ValueError('支持 PDF、DOCX、XLSX、文本、代码和图片')
    if len(text) > LIMIT: raise ValueError('文件文本超过 10 万字符，请拆分后上传；未截断分析')
    if not text.strip(): raise ValueError('文件中没有可分析的文字')
    return text

if __name__ == '__main__':
    try:
        # Bound untrusted decompression/PDF parsing independently of the web process.
        if sys.platform.startswith('linux'):
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (512*1024*1024,512*1024*1024))
            resource.setrlimit(resource.RLIMIT_CPU, (20,20))
        print(json.dumps({'text':extract(sys.argv[1],sys.argv[2])}, ensure_ascii=False))
    except Exception as e:
        # Return known validation errors only; do not expose host paths.
        print(json.dumps({'error':str(e) if isinstance(e,ValueError) else '无法解析该文件，请检查格式或转换为 PDF/文本'}, ensure_ascii=False))
        sys.exit(1)
