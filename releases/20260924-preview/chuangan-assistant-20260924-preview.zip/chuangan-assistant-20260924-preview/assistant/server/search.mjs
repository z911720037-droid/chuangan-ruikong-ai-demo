const decode=s=>s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&#(x[0-9a-f]+|\d+);/gi,(_,n)=>{const v=n[0].toLowerCase()==='x'?parseInt(n.slice(1),16):Number(n);return v<=0x10ffff?String.fromCodePoint(v):''}).replace(/&(amp|lt|gt|quot|apos);/g,(_,n)=>({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"}[n]));
const field=(s,k)=>decode(s.match(new RegExp('<'+k+'(?:\\s[^>]*)?>([\\s\\S]*?)</'+k+'>','i'))?.[1]||'').replace(/<[^>]*>/g,'').trim();
export function publicUrl(value){try{const u=new URL(value);if(u.protocol!=='https:'&&u.protocol!=='http:')return null;if(u.username||u.password||u.hostname==='localhost'||/^(?:127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(u.hostname)||u.hostname.includes(':')||!u.hostname.includes('.'))return null;return u.href}catch{return null}}
export function parseRSS(xml){
 if(!/<rss[\s>]/i.test(xml))throw new Error('搜索服务返回了异常页面，请稍后重试');
 return [...xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)].map(m=>({title:field(m[1],'title'),url:publicUrl(field(m[1],'link')),snippet:field(m[1],'description'),published:field(m[1],'pubDate')})).filter(x=>x.url&&x.title).slice(0,6);
}
export async function webSearch(query,{fetcher=fetch,signal}={}){
 if(typeof query!=='string'||!query.trim()||query.length>500)throw new Error('搜索词长度无效');
 const url=new URL('https://www.bing.com/search');url.searchParams.set('format','rss');url.searchParams.set('q',query);
 const response=await fetcher(url,{headers:{Accept:'application/rss+xml, application/xml'},signal:signal?AbortSignal.any([signal,AbortSignal.timeout(15000)]):AbortSignal.timeout(15000)});
 if(!response.ok)throw new Error('联网搜索暂不可用（'+response.status+'），未生成搜索结果');
 const decoder=new TextDecoder();let xml='',size=0;for await(const b of response.body){size+=b.length;if(size>512000)throw new Error('搜索结果过大');xml+=decoder.decode(b,{stream:true})}xml+=decoder.decode();
 const results=parseRSS(xml);if(!results.length)throw new Error('没有取得可用搜索结果，请调整关键词');
 return {query,provider:'Bing RSS',retrievedAt:new Date().toISOString(),scope:'搜索标题与摘要，未读取网页全文',results};
}
