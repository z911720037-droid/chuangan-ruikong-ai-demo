# 创安睿控产品助手 · 20260924 预览源码包

最新网页与后端代码：公司产品范围问答、官网资料检索和主动查找、深度思考、上传资料、多轮会话、动态延伸问题。Node.js 后端，Python 解析文档；无需 Qdrant、Embedding 或访客安装模型。

## 包含和排除

包含官网公开资料提取索引、服务器/网页源码与离线单元测试。官网快照日期2026-09-22，238网页、72个PDF入口、145张图片；仅包含提取数据，原始附件不打包。资料并非逐参数人工核验。

为保护客户资料，公开包排除了客户100问原文与对应语料（faqCount=0），所以与内部预览版的知识范围有此差异。密钥、密码、内部部署地址、运行日志、上传文件及内部项目计划书均未打包。客户问答可在受控环境另行恢复，不应提交公开GitHub。

## Linux 启动

安装 Node.js 22+、Python 3、python3-venv。解压后在本目录执行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r assistant/requirements.txt
cp .env.example .env
chmod 600 .env
# 编辑 .env，将 DEEPSEEK_API_KEY 替换为您自己的服务端密钥
export ASSISTANT_PYTHON="$PWD/.venv/bin/python"
node --env-file=.env assistant/server/main.mjs
```

浏览器访问 http://127.0.0.1:18083/ 。如果运行在远程Linux，请通过SSH转发此端口，或由管理员配置HTTPS反向代理及正确的PUBLIC_ORIGIN。模型名受账号及供应商支持情况影响，可在.env调整；密钥不得写入前端。

## 离线验证

```bash
node assistant/tests/official-unit.mjs
node assistant/tests/reasoning-unit.mjs
node assistant/tests/format-unit.mjs
```

这些测试验证代码规则，部分模型调用用固定测试响应代替，不代表实际模型准确率、持续20并发验收或上线批准。请参阅 VALIDATION.md。

## 当前限制

此包为预览版归档，未通过正式生产门禁。语音转文字、直接拍照、微信登录仍为后续计划；现有图片上传不等于直接拍照。旧GitHub Pages静态网页不自动更新，也不能运行本包Node/Python后端。

不得将Github上传等同于切换生产服务。正式部署仍需独立人工复核、持续负载、HTTPS与运维配置。当前限流按单进程与连接IP统计，反向代理及多实例部署需另行适配。
